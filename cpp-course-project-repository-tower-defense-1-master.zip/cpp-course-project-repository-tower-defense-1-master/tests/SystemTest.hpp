#include <iostream>
#include <SFML/Window.hpp>

int SystemTest();