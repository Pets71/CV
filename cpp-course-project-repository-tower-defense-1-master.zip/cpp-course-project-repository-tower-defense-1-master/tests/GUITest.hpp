#pragma once
#include "src/GUI/GUI.hpp"

int GUITest();