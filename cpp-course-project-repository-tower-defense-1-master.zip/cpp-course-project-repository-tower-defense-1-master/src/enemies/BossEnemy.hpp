#pragma once
#include "Enemy.hpp"

class BossEnemy : public Enemy {
 public:
  BossEnemy();
  ~BossEnemy();
};