#pragma once
#include "Enemy.hpp"

class FinalBoss : public Enemy {
 public:
  FinalBoss();
  ~FinalBoss();
};