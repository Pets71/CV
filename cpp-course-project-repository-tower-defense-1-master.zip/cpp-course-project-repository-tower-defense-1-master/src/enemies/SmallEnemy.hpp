#pragma once
#include "Enemy.hpp"

class SmallEnemy : public Enemy {
 public:
  SmallEnemy();
  ~SmallEnemy();
};