#pragma once
#include "Enemy.hpp"

class BigEnemy : public Enemy {
 public:
  BigEnemy();
  ~BigEnemy();
};