#pragma once
#include "Tile.hpp"

class EmptyTile : public Tile {
 public:
  EmptyTile();
  ~EmptyTile();
};
