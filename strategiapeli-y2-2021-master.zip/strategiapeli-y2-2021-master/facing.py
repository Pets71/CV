
class Facing:

    UP = 1
    RIGHT = 2
    DOWN = 3
    LEFT = 4

    @staticmethod
    def turn_left(current):
        if current == Facing.UP:
            return Facing.LEFT
        else:
            return current -1

    @staticmethod
    def turn_right(current):
        if current == Facing.LEFT:
            return Facing.UP
        else:
            return current +1

    @staticmethod
    def degrees(current):

        return (int(current)-1) * 90