from square import Square

class Wall(Square):
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.type = Wall
        self.contains = None
        self.graphic = None
        self.state = 0
        self.level = None

