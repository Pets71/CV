
class Item:
    # item stat is amount of health gained
    Bandage = (5)
    Ration = (2)


    @staticmethod
    def get_health(item):
        if item == None:
            return None
        elif len(str(item)) != 1:
            return None
        else:
            return int(item)

class Weapon(Item):
    # weapon stats are in order: (range,damage,sound,energy consumption)
    Knife = (1,50,0,0)
    Pistol = (5,3,3,1)
    SilencedPistol = (5,2,1,1)
    Shotgun = (6,10,10,4)
    Rifle = (8,5,6,3)
    Sniper = (14,50,10,6)

    WeaponGraphicsList = {Knife : "knife.png"}

    @staticmethod
    def get_range(item):
        if item == None:
            return None
        else:
            return int(item[0])

    @staticmethod
    def get_damage(item):
        if item == None:
            return None
        else:
            return int(item[1])

    @staticmethod
    def get_sound(item):
        if item == None:
            return None
        else:
            return int(item[2])

    @staticmethod
    def get_energy_cost(item):
        if item == None:
            return None
        else:
            return int(item[3])
