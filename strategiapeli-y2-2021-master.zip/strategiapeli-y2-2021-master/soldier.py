from enemy import Enemy
from facing import Facing
from item import Weapon
from graphics_item import  Graphics_Item

class Soldier(Enemy):

    def __init__(self,x,y,facing,id,level):
        self.x = int(x)
        self.y = int(y)
        self.level = level
        self.id = id
        self.route = []
        self.temproute = []
        self.temproutestep = 0
        self.hasreachedtemprouteend = False
        self.atbeginning = False
        self.graphicitem = None
        self.routestep = 0
        self.movement = 3
        self.hp = 10
        self.weapon = Weapon.Rifle
        self.enemytype = Soldier
        self.facing = facing
        self.visible = False
        self.graphics = "Enemy_Anna.png"
        self.square = level.get_square(x, y)
        self.movesound = 3
        self.visionrange = 5



    def checkroute(self):

        if self.route[self.routestep] == [str(self.x), str(self.y)]:

            if self.routestep == len(self.route) -1:
                self.routestep = 0
            else:
                self.routestep += 1
            if self.x > int(self.route[self.routestep][0]):
                self.facing = Facing.RIGHT
                return
            if self.x < int(self.route[self.routestep][0]):
                self.facing = Facing.LEFT
                return
            if self.y > int(self.route[self.routestep][1]):
                self.facing = Facing.UP
                return
            if self.y < int(self.route[self.routestep][1]):
                self.facing = Facing.DOWN
                return

    def checktemproute(self):
        if self.temproute[self.temproutestep] == [self.x, self.y]:
            if not self.hasreachedtemprouteend:
                if self.temproutestep == len(self.temproute) -1:
                    self.hasreachedtemprouteend = True
                else:
                    self.temproutestep += 1
            elif self.hasreachedtemprouteend:
                if self.temproutestep > 0:
                    self.temproutestep -= 1
                else:
                    self.atbeginning = True
            if self.x > int(self.temproute[self.temproutestep][0]):
                self.facing = Facing.RIGHT
                return
            if self.x < int(self.temproute[self.temproutestep][0]):
                self.facing = Facing.LEFT
                return
            if self.y > int(self.temproute[self.temproutestep][1]):
                self.facing = Facing.UP
                return
            if self.y < int(self.temproute[self.temproutestep][1]):
                self.facing = Facing.DOWN
                return




    def maketemproute(self):
        self.hasreachedtemprouteend = False
        self.atbeginning = False
        self.temproute = [[self.x,self.y]]
        if self.level.lastseenpos.x == self.x:
            if self.level.get_can_see(self.x, self.y, self.level.lastseenpos.x, self.level.lastseenpos.y):
                self.temproute = [[self.x,self.y],[self.level.lastseenpos.y,self.level.lastseenpos.x]]

        elif self.level.lastseenpos.y == self.y:
            if self.level.get_can_see(self.x, self.y,  self.level.lastseenpos.x, self.level.lastseenpos.y):
                self.temproute = [[self.x,self.y],[self.level.lastseenpos.y,self.level.lastseenpos.x]]

        elif self.level.get_can_see(self.x, self.y, self.level.lastseenpos.x, self.y) and self.level.get_can_see(self.level.lastseenpos.x, self.y,self.level.lastseenpos.x,self.level.lastseenpos.y):
            self.temproute  = [[self.x,self.y],[self.y,self.level.lastseenpos.x],[self.level.lastseenpos.y, self.level.lastseenpos.x]]
        elif self.level.get_can_see(self.x, self.y, self.x, self.level.lastseenpos.y) and self.level.get_can_see(self.x, self.level.lastseenpos.y,self.level.lastseenpos.x,self.level.lastseenpos.y):
            self.temproute  = [[self.x,self.y],[ self.level.lastseenpos.y, self.x],[self.level.lastseenpos.y, self.level.lastseenpos.x]]


        else:
            difference = 1
            tried1 = False
            tried2 = False
            while True:
                if tried1 and tried2:
                    break
                if self.y + difference < int(self.level.width):
                    if self.level.get_can_see(self.x, self.y, self.x, self.y + difference) and self.level.get_can_see(self.x, self.y + difference,self.level.lastseenpos.x, self.y + difference) and self.level.get_can_see(self.level.lastseenpos.x, self.y + difference,self.level.lastseenpos.x,self.level.lastseenpos.y):
                        self.temproute = [[self.x,self.y],[ self.y + difference , self.x],[ self.y + difference, self.level.lastseenpos.x],[self.level.lastseenpos.y, self.level.lastseenpos.x]]
                        break
                else:
                    tried1 = True
                if self.y - difference >= 0:
                    if self.level.get_can_see(self.x, self.y, self.x, self.y - difference) and self.level.get_can_see(self.x, self.y - difference,self.level.lastseenpos.x, self.y - difference) and self.level.get_can_see(self.level.lastseenpos.x, self.y - difference,self.level.lastseenpos.x,self.level.lastseenpos.y):
                        self.temproute = [[self.x,self.y],[ self.y - difference , self.x],[ self.y - difference, self.level.lastseenpos.x],[self.level.lastseenpos.y, self.level.lastseenpos.x]]
                        break
                else:
                    tried2 = True
                difference += 1

            difference = 1
            tried1 = False
            tried2 = False
            while True:
                if tried1 and tried2:
                    break
                if self.x + difference < int(self.level.width):
                    if self.level.get_can_see(self.x, self.y, self.x+difference, self.y) and self.level.get_can_see(self.x+difference, self.y,self.x+difference, self.level.lastseenpos.y) and self.level.get_can_see(self.x+difference, self.level.lastseenpos.y,self.level.lastseenpos.x,self.level.lastseenpos.y):
                        self.temproute = [[self.x,self.y],[ self.y,self.x+difference],[self.level.lastseenpos.y,self.x+difference],[self.level.lastseenpos.y, self.level.lastseenpos.x]]
                        break
                else:
                    tried1 = True
                if self.x - difference >= 0:
                    if self.level.get_can_see(self.x, self.y, self.x - difference,self.y) and self.level.get_can_see(self.x - difference, self.y,self.x - difference,self.level.lastseenpos.y) and self.level.get_can_see(self.x - difference, self.level.lastseenpos.y, self.level.lastseenpos.x,self.level.lastseenpos.y):
                        self.temproute = [[self.x,self.y], [ self.y, self.x - difference],[self.level.lastseenpos.y, self.x - difference],[self.level.lastseenpos.y, self.level.lastseenpos.x]]
                        break
                else:
                    tried2 = True
                difference += 1





    def make_normal_move(self):
        movesleft = self.movement
        while True:
            if movesleft <= 0:
                break
            if self.cansee():
                break
            self.checkroute()
            if self.x > int(self.route[self.routestep][0]):
                self.x -= 1
            elif self.x < int(self.route[self.routestep][0]):
                self.x += 1
            elif self.y > int(self.route[self.routestep][1]):
                self.y -= 1
            elif self.y < int(self.route[self.routestep][1]):
                self.y += 1
            movesleft -= 1
            self.square = self.level.get_square(self.x, self.y)
            self.level.set_sounds(self.square, self.movesound, self,True)
            self.graphicitem.update_location()
        self.checkroute()
        self.graphicitem.update_location()

    def make_chase_move(self):
        movesleft = self.movement
        while True:
            if movesleft <= 0:
                break
            if self.cansee():
                break
            if self.temproutestep < len(self.temproute):
                self.checktemproute()
                if self.x > int(self.temproute[self.temproutestep][0]):
                    self.x -= 1
                elif self.x < int(self.temproute[self.temproutestep][0]):
                    self.x += 1
                elif self.y > int(self.temproute[self.temproutestep][1]):
                    self.y -= 1
                elif self.y < int(self.temproute[self.temproutestep][1]):
                    self.y += 1
            else:
                oldfacing = self.facing
                self.facing = Facing.turn_left(oldfacing)
                if self.cansee():
                    break
                self.facing = Facing.turn_right(oldfacing)
                if self.cansee():
                    break
                break
            movesleft -= 1
            self.square = self.level.get_square(self.x, self.y)
            self.level.set_sounds(self.square, self.movesound, self,True)
            self.graphicitem.update_location()
        self.checktemproute()
        self.graphicitem.update_location()

    def shoot(self):
        wppossiblemap = self.level.get_possible_squares(self.x, self.y, Weapon.get_range(self.weapon))
        if wppossiblemap[self.level.player.y][self.level.player.x]:
            if self.level.get_can_see(self.y, self.x, self.level.player.y, self.level.player.x):
                self.level.player.lose_hp(Weapon.get_damage(self.weapon))
                self.level.set_sounds(self.square, Weapon.get_sound(self.weapon), self,True)
                self.level.lastseenpos = self.level.player.get_square()
            else:
                self.level.enemystate = 3
                self.level.searchtime = 3
        else:
            self.level.enemystate = 3
            self.level.searchtime = 3


    def cansee(self):
        if self.vision_cone_cansee(self.level.player):
            self.level.set_sounds(self.square,100,self,False)
            self.level.enemystate = 2
            self.level.lastseenpos = self.level.player.get_square()
            return True
        else:
            return False

