

class Square():

    def __init__(self, x, y):
        pass


    def get_type(self):
        return self.type


    def add_graphic(self,graphic):
        self.graphic = graphic

    def set_state(self,state):
        self.state = state
        self.set_graphic_state()

    def set_graphic_state(self):
        self.graphic.set_state(self.state)
        self.graphic.update_colour()

    def add_item(self,item):
        if item == None:
            self.contains = item
            return None
        elif self.contains != None:
            self.contains = item
            return True
        else:
            return False

    def do_action(self):
        self.level.do_level_action(self.x,self.y)

    def add_level(self,level):
        self.level = level