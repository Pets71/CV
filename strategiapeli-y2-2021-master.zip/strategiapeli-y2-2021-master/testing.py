
from item import *
from level_loader import levelloader
from empty import Empty
from facing import Facing
from player import Player



import unittest
class SampleTest(unittest.TestCase):

    #lataa testikentän
    def levelloadtest(self):
        file = "testlevel.txt"
        taso = levelloader(file)
        return taso
    #latautuuko kenttä oikein, id ja ruutu
    def test_load(self):
        taso = self.levelloadtest()
        self.assertNotEqual(taso.get_squaretype(2,3),Empty)
        self.assertEqual(int(taso.level_id), 42)
    #helppo kääntymistesti
    def test_facing(self):
        facing = "UP"
        self.assertTrue(Facing.turn_left(Facing.LEFT) == Facing.DOWN)
    #testi ovatko tavarat oikein ja niiden kutsumetodit oikein
    def test_item(self):
        self.assertEqual(Weapon.Shotgun, (6,10,10,4))
        self.assertEqual(Weapon.get_range(Weapon.Shotgun),6)
        self.assertEqual(Item.Ration,2)
        self.assertEqual(Item.get_health(Item.Ration),2)
    #testataan toimiiko inventoryn lataus ja tallennus(koko inventoryja ei voi verrata, koska tavarat muutetaan takaisin numeroihin metodeissa.
    def test_inventory(self):
        player = Player(1,1,Facing.UP,self.levelloadtest())
        player.add_to_inventory(Item.Bandage)
        player.add_to_inventory(Item.Bandage)
        player.add_to_inventory(Item.Ration)
        player.add_to_inventory(Weapon.SilencedPistol)
        startinventory = player.inventory
        player.inventory = [None] * 8
        player.load_state()

        self.assertEqual(player.inventory[4] , startinventory[4])


    #tuleeko mahdollisten ruutujen kartta oikein
    def test_possiblemap(self):
        taso = self.levelloadtest()
        map = taso.get_possible_squares(1,5,3)
        self.assertTrue(map[2][4])
        self.assertTrue( not map[3][2])



    #toimiiko näkölinja oikein
    def test_cansee(self):
        taso = self.levelloadtest()
        self.assertTrue(taso.get_can_see(1,6,3,3))

    #testataan johtaako jahtausreitti, johtaako viimeksi nähtyyn pisteeseen
    def test_temproute(self):
        taso = self.levelloadtest()
        taso.lastseenpos = taso.grid[5][3]
        for enemy in taso.enemies:
            enemy.maketemproute()
            if len(enemy.temproute) > 1:
                self.assertEqual(enemy.temproute[-1] , [3,5])

unittest.main()

#pari metodia, jotka hyödyntävät levelloadtestiä, ja printtaavat tulokset komentoriviin

#def get_squaretypes(self):
#    taso = levelloadtest()
#    for y in range(int(taso.get_width())):
#        for x in range(int(taso.get_height())):
#            print(x, y, taso.get_squaretype(x, y), end="")
#        print("")

#def pathprint(self):
#    taso = levelloadtest()
#    for enemy in taso.enemies:
#        print(enemy.get_route())




