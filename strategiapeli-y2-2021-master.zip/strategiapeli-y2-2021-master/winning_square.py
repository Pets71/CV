from square import Square

class Winning_Square(Square):
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.type = Winning_Square
        self.contains = None
        self.graphic = None
        self.state = 0
        self.level = None

    def includes(self):
        return self.contains

    def add(self, item):
        self.contains = item

    def is_empty(self):
        return self.contains == None