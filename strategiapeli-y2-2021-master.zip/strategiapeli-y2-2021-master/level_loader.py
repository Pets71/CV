from level import Level

def levelloader(source):
    try:
        source = open(source,"r")
        line = source.readline()
        while True:
            if not line:
                break
            line.rstrip("\n")
            if line[0] == "#":
                ## täytyy olla tässä järjestyksessä, vihut on ruudussa, ja pathit on vihun ominaisuus.
                line = line.rstrip("\n")
                line = line.strip("\n")
                if line == "#layout":
                    line = source.readline()
                    level_id = line.rstrip("\n")
                    line = source.readline()
                    line.rstrip("\n")
                    parts = line.split(",")
                    width = parts[0]
                    height = parts[1]
                    taso = Level(level_id,width, height)
                    y = 0
                    while True:
                        line = source.readline()
                        line.rstrip("\n")
                        if not line:
                            break
                        elif line[0] == "#":
                            break
                        row = line.split(",")
                        x = 0
                        for squares in row:
                            squares = squares.rstrip("\n")
                            taso.add_square(x,y,squares)
                            x += 1
                        y += 1
                    taso.add_player()
                elif line == "#enemies":
                    line = source.readline()
                    line.rstrip("\n")
                    line = line.strip("\n")
                    enemyparts = line.split(",")

                    while True:
                        if not line:
                            break
                        elif line[0] == "#":
                            break

                        taso.add_enemy(enemyparts[0],enemyparts[1],enemyparts[2],enemyparts[3],enemyparts[4])
                        line = source.readline()
                        line.rstrip("\n")
                        line = line.strip("\n")
                        enemyparts = line.split(",")

                elif line == "#enemypaths":
                    line = source.readline()
                    line = line.rstrip("\n")
                    line = line.strip("\n")
                    while True:
                        if not line:
                            break
                        elif line[0] == "#":
                            break
                        for enemy in taso.enemies:
                            if int(line[0]) == int(enemy.get_id()):
                                enemy.add_route(line)
                        line = source.readline()
                        line.rstrip("\n")
                        line = line.strip("\n")

                elif line == "#loot":
                    line = source.readline()
                    line = line.rstrip("\n")
                    line = line.strip("\n")

                    while True:
                        if not line:
                            break
                        elif line[0] == "#":
                            break
                        parts = line.split(",")
                        taso.add_box(parts[0],parts[1])
                        line = source.readline()
                        line = line.rstrip("\n")
                        line = line.strip("\n")
            if not line:
                break
            if line[0] != "#":
                line = source.readline()

    except OSError:
        print("¯\_(ツ)_/¯")
    finally:
        source.close()
    taso.add_player()
    return taso


