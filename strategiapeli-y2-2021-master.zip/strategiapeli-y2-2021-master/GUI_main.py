from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtGui import QColor, QPixmap
from graphics_item import Graphics_Item
from level import Level
from wall import Wall
from empty import Empty
from enemy import Enemy
from  seccam import SecurityCamera
from graphics_special import Graphics_special
from graphics_square import Graphics_square
from box import *

class MainGUI(QtWidgets.QMainWindow):

    def __init__(self, level, *args, **kwargs):
        super(MainGUI,self).__init__(*args, **kwargs)
        self.setWindowTitle("Loading Window")
        self.setCentralWidget(QtWidgets.QWidget())
        self.vertical = QtWidgets.QVBoxLayout()
        self.horisontal = QtWidgets.QHBoxLayout()
        self.centralWidget().setLayout(self.vertical)
        self.level = level
        self.init_game_window()
        self.init_actions()
        self.init_squares()
        self.init_enemies()
        self.init_boxes()
        self.init_player()
        self.square_size = 40
        self.activesounds = []
        self.level.set_GUI(self)
        self.show()
        self.level.reset_state()



    def init_actions(self):
        self.testbutton1 = QtWidgets.QPushButton("wait a turn")
        self.testbutton1.clicked.connect(self.run_turns)
        self.vertical.addWidget(self.testbutton1)
        self.testbutton2 = QtWidgets.QPushButton("make a move")
        self.testbutton2.clicked.connect(self.start_move)
        self.vertical.addWidget(self.testbutton2)
        self.weaponbutton = QtWidgets.QPushButton("attack")
        self.weaponbutton.clicked.connect(self.level.use_weapon)
        self.vertical.addWidget(self.weaponbutton)
        self.temproutestep1 = QtWidgets.QPushButton("use item")
        self.temproutestep1.clicked.connect(self.use_item)
        self.vertical.addWidget(self.temproutestep1)
        self.temproutestep2 = QtWidgets.QPushButton("open box")
        self.temproutestep2.clicked.connect(self.level.open_box)
        self.vertical.addWidget(self.temproutestep2)

    def init_game_window(self):
        self.setGeometry(300, 300, 800, 800)
        self.setWindowTitle('SUPER SNEAKY CYBORG 16: Attack of the Blerghs; The Movie, The Game ')
        self.show()

        self.scene = QtWidgets.QGraphicsScene()
        self.scene.setSceneRect(0, 0, 700, 700)

        # Add a view for showing the scene
        self.view = QtWidgets.QGraphicsView(self.scene, self)
        self.view.adjustSize()
        self.view.show()
        self.vertical.addWidget(self.view)

    def init_boxes(self):
        for box in self.level.boxes:
            Box_Graphic(box,self.scene)

    def init_squares(self):
        level = self.level
        for x in range(int(level.get_width())):
            for y in range(int(level.get_height())):
                ruututyyppi = level.get_squaretype(x,y)
                ruutu = level.get_square(x,y)
                Graphics_square(x,y,ruutu,ruututyyppi,self.scene)

    def use_item(self):
        item = self.open_inventory()
        if item == None:
            return
        elif len(str(item)) == 1:
            self.level.player.hp += Item.get_health(item)
            self.level.player.remove_item_from_inventory(item)
            return
        elif len(item) == 4:
            self.level.player.select_active_weapon(item)
            return



    def open_inventory(self):
        back = None
        inventorydict = {None : "empty" ,(5) : "Bandage",(2):"Ration",(1,50,0,0):"Knife",(5,3,3,1):"Pistol",(5,2,1,1):"Silenced Pistol", (6,10,10,4):"Shotgun",(8,5,6,3):"Rifle", (14,50,10,6): "Sniper"}
        inventorylist = []
        for item in self.level.player.inventory:
            inventorylist.append(inventorydict[item])
        inventoryitem, ok = QtWidgets.QInputDialog.getItem(self,"Inventory","current energy is:{:}\ncurrent health is:{:}".format(self.level.player.energy,self.level.player.hp),inventorylist,0,False)
        for key in inventorydict.keys():
            if inventorydict[key] == inventoryitem:
                back = key
        if ok:
            return back
        else:
            return None




    def init_enemies(self):
        level = self.level
        for enemy in level.enemies:
            Graphics_Item(self.scene, enemy)

    def  create_sounds(self):
        for oldsound in self.activesounds:
            self.scene.removeItem(oldsound.graphic)
        self.activesounds = []
        for sound in self.level.sounds:
            if sound.can_hear(self.level.player):
                self.activesounds.append(Graphics_special(sound,self.scene))

    def init_player(self):
        Graphics_Item(self.scene, self.level.player)

    def win_popup(self):
        popup = QtWidgets.QMessageBox()
        popup.setWindowTitle("You Win!")
        popup.setText("do you want to continue?\n(not yet working)")
        popup.setStandardButtons(QtWidgets.QMessageBox.Yes|QtWidgets.QMessageBox.No)
        x = popup.exec_()

    def lose_popup(self):
        popup = QtWidgets.QMessageBox()
        popup.setWindowTitle("You Lose!")
        popup.setText("do you want to restart?\n(not yet working)")
        popup.setStandardButtons(QtWidgets.QMessageBox.Yes|QtWidgets.QMessageBox.No)

        x = popup.exec_()




    def update_enemy(self,enemy):
        pass

    def run_turns(self):
        self.level.run_enemies()

    def start_move(self):
        self.level.make_move()


