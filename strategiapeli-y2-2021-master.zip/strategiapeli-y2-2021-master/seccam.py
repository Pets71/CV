from enemy import Enemy
from facing import Facing

class SecurityCamera(Enemy):

    def __init__(self, x, y, facing,id,level):
        self.level = level
        self.x = int(x)
        self.y = int(y)
        self.id = id
        self.hp = 1
        self.visionrange = 5
        self.graphicitem = None
        self.atbeginning = True
        self.turning = 1
        self.turnsycle = False
        self.route = [[x,y]]
        self.temproute = [[x,y]]
        self.routestep = 0
        self.enemytype = SecurityCamera
        self.facing = facing
        self.visible = False
        self.graphics = "seccam.png"
        self.square = level.get_square(x, y)

    def make_normal_move(self):
        if self.turnsycle:
            self.facing = Facing.turn_right(self.facing)
            self.turning -= 1
            self.cansee()
            if self.turning <= 0:
                self.turnsycle = False
            return
        else:
            self.facing = Facing.turn_left(self.facing)
            self.turning += 1
            self.cansee()
            if self.turning >= 2:
                self.turnsycle = True
            return

    def cansee(self):
        if self.vision_cone_cansee(self.level.player):
            self.level.enemystate = 2
            self.level.lastseenpos = self.level.player.get_square()
            return True
        else:
            return False

    def shoot(self):
        possiblemap = self.level.get_possible_squares(self.x, self.y,self.visionrange)
        if possiblemap[self.level.player.y][self.level.player.x]:
            if  self.level.get_can_see(self.x,self.y,self.level.player.y,self.level.player.x):
                self.level.enemystate = 2
                self.level.lastseenpos = self.level.player.get_square()


    def make_chase_move(self):
        self.make_normal_move()

    def maketemproute(self):
        pass