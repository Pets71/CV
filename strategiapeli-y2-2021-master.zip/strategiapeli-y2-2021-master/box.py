from PyQt5 import QtGui, QtWidgets
import random
from item import *

class Box:

    def __init__(self,x,y,level):
        self.loottable = (Weapon.SilencedPistol,Weapon.Sniper,Item.Bandage,Item.Ration, Item.Ration,Item.Ration,"ammo","ammo","ammo","ammo","ammo","ammo")
        self.level = level
        self.square = self.level.get_square(int(y),int(x))
        self.x = x
        self.y = y
        self.loot = []
        self.targetgraphic = None
        luku = random.randrange(1,4)
        for i in range(luku):
            self.loot.append(self.loottable[random.randrange(0,(len(self.loottable)))])


    def looted(self):
        for item in self.loot:
            if item == "ammo":
                self.level.player.energy += 5
            else:
                self.level.player.add_to_inventory(item)
        if len(self.level.boxes) == 1:
            self.level.boxes = []
        else:
            self.level.boxes.remove(self)
        self.targetgraphic.remove_self()

    def addtargetgraphic(self,graphic):
        self.targetgraphic = graphic

    def get_graphics_location(self,squaresize):
        return (int(self.x)*squaresize, int(self.y)*squaresize)

    def isvisiblecheck(self):
        if self.square.state != 2:
            return True
        else:
            return False

class Box_Graphic:

    def __init__(self,target,scene):
        self.target = target
        target.addtargetgraphic(self)
        self.scene = scene
        self.position = self.target.get_graphics_location(40)
        graphics = QtGui.QPixmap("box.png")
        gitem = QtWidgets.QGraphicsPixmapItem()
        gitem.setTransformOriginPoint(20, 20)
        gitem.setPixmap(graphics)
        self.graphic = gitem
        self.scene.addItem(gitem)
        self.graphic.setPos(self.position[1], self.position[0])
        self.isvisible()

    def isvisible(self):
        if self.target.isvisiblecheck():
            self.graphic.show()
        else:
            self.graphic.hide()

    def remove_self(self):
        self.scene.removeItem(self.graphic)
