from square import Square
from player import Player
class Sound():

    def __init__(self,level,square,range,cause,sound):
        self.is_sound = sound
        self.cause = cause
        self.level = level
        self.x = square.x
        self.y = square.y
        self.range = range
        self.graphic = None

    def get_square(self):
        print(self.x,self.y)
        return self.level.get_square(self.x,self.y)

    def get_graphics_location(self,squaresize):
        return (int(self.x)*squaresize, int(self.y)*squaresize)

    def can_hear_calc(self,x,y):
        possiblemap = self.level.get_possible_squares(self.y,self.x,self.range)
        if possiblemap[y][x]:
            return True
        else:
            return False

    def can_hear(self,target):
        if target != self.cause:
            return self.can_hear_calc(target.x, target.y)

    def get_graphics(self):
        if self.is_sound:
            return ("sound effect graphic.png")
        else:
            return ("detection.png")



