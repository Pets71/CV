from PyQt5 import QtGui, QtWidgets
class Graphics_special():

    def __init__(self,target,scene):
        self.target = target
        self.graphicitem = None
        target.graphic = self
        self.scene = scene
        self.position = self.target.get_graphics_location(40)
        graphics = QtGui.QPixmap(self.target.get_graphics())
        gitem = QtWidgets.QGraphicsPixmapItem()
        gitem.setTransformOriginPoint(20, 20)
        gitem.setPixmap(graphics)
        self.graphic = gitem
        self.graphic.setPos(self.position[1], self.position[0])
        self.graphic.show()
        self.scene.addItem(gitem)
