import sys
from level_loader import levelloader
from GUI_main import MainGUI
from PyQt5.QtWidgets import QApplication

def main():

    taso = None

    global app
    file = "Testlevel.txt"
    taso = levelloader(file)
    app = QApplication(sys.argv)
    gui = MainGUI(taso)
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
