from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtGui import QColor, QInputEvent
from PyQt5.QtCore import Qt, QPointF
from wall import Wall
from empty import Empty
from winning_square import Winning_Square
from square import Square

class Graphics_square(QtWidgets.QGraphicsRectItem):

    def __init__(self,x,y,tsquare,type,scene):
        super(Graphics_square, self).__init__()
        self.squarecolourdict = {Wall: QColor(40, 40, 40), Empty: QColor(200, 200, 200),Winning_Square: QColor(75,175,75)}
        self.x = x
        self.y = y
        self.type = type
        self.targetsquare = tsquare
        self.targetsquare.add_graphic(self)
        self.scene = scene
        self.natcolour = self.squarecolourdict[self.type]
        self.setRect(x * 40, y * 40, 40, 40)
        self.setBrush(self.natcolour)
        self.show()
        self.scene.addItem(self)
        ##states are: 0: normal state, 1: available for selected action, 2 : not seen by player
        self.state = 0

    def update_colour(self):
        if self.type != Wall:
            if self.state == 1:
                self.setBrush(QColor(255, 255, 51))
            elif self.state == 2:
                self.setBrush(QColor(150, 150, 150))
            else:
                self.setBrush(self.natcolour)

    def set_state(self, state):
        self.state = state

    def mousePressEvent(self, event):
        if self.state == 1:
            self.targetsquare.do_action()
