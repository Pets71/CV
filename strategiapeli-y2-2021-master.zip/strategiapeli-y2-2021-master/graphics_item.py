from enemy import Enemy
from PyQt5 import QtGui, QtWidgets

class Graphics_Item():

    def __init__(self,scene, target):
        self.target = target
        self.graphicitem = None
        target.addtargetgraphic(self)
        self.scene = scene
        self.position = self.target.get_graphics_location(40)
        self.facing = self.target.get_facing_degree()
        graphics = QtGui.QPixmap(self.target.get_graphics())
        gitem = QtWidgets.QGraphicsPixmapItem()
        gitem.setTransformOriginPoint(20, 20)
        gitem.setPixmap(graphics)
        self.graphic = gitem
        self.scene.addItem(gitem)
        self.update_location()

    def deletegraphic(self):
        self.scene.removeItem(self.graphic)


    def isvisible(self):
        if self.target.isvisible():
            self.graphic.show()
        else:
            self.graphic.hide()

    def update_location(self):
        self.position = self.target.get_graphics_location(40)
        self.facing = self.target.get_facing_degree()
        self.graphic.setRotation(self.facing)
        self.graphic.setPos(self.position[1], self.position[0])
        self.isvisible()



