from square import Square
from empty import Empty
from wall import Wall
from winning_square import Winning_Square
from soldier import Soldier
from seccam import SecurityCamera
from facing import Facing
from player import Player
from sound import Sound
from item import Item, Weapon
from box import Box

class Level():

    def __init__(self, id ,width, height):
        self.width = width
        self. level_id = id
        self.height = height
        self.enemies = []
        self.boxes = []
        self.player = None
        self.state = 0
        #enemy states are 0: normal, 1: heard sound, 2: seen player, 3: looking at last seen position, similar to 1
        self.enemystate = 0
        self.lastseenpos = None
        self.searchtime = 0
        self.GUI = None
        self.sounds = []
        self.grid = [None] * int(self.width)
        for x in range(int(width)):
            self.grid[x] = [None]* int(self.height)

    def set_GUI(self,gui):
        self.GUI = gui

    def add_square(self, x,y,type):
        self.typedict = {"0": Empty, "1": Wall, "2": Winning_Square}
        for i in self.typedict:
            if i == type:
                self.grid[x][y] = self.typedict[type](x, y)
                self.grid[x][y].add_level(self)
                return

    def add_player(self):
        tempx = 1
        tempy = 15
        tempfacing = Facing.UP
        self.player = Player(tempx,tempy,tempfacing,self)
        self.player.add_to_inventory(Weapon.Knife)
        self.player.add_to_inventory(Weapon.Rifle)
        self.player.add_to_inventory(Item.Bandage)
        self.player.select_active_weapon(Weapon.Knife)

    def add_box(self, x, y):
        self.boxes.append(Box(x,y,self))


    def add_enemy(self,type,x,y,facing,id):
        currentenemy = None
        self.enemydict = {"a": Soldier, "b": SecurityCamera}
        self.facingdict = {"UP": Facing.UP, "RIGHT" : Facing.RIGHT, "DOWN": Facing.DOWN, "LEFT": Facing.LEFT}
        for j in self.enemydict:
            if j == type:
                currentenemy = self.enemydict[type](x, y, self.facingdict[facing],id,self)
                self.enemies.append(currentenemy)
                if self.get_squaretype(x,y) != Wall:
                    self.get_square(x,y).add_item(currentenemy)
                    return True
                else:
                    return False


    def get_squaretype(self,x,y):
        try:
            return self.get_square(x, y).get_type()
        except TypeError:
            return None

    def get_square(self, x, y):
        try:
            return self.grid[int(x)][int(y)]
        except IndexError:
            return None

    def get_width(self):
        return self.width

    def get_height(self):
        return self.height

    def get_possible_squares(self,x,y,distance):
        width = int(self.width)
        height = int(self.height)
        possiblemap = [None] * width
        for k in range(int(width)):
            possiblemap[k] = [False] *height
        possiblemap[x][y] = True
        while True:
            if distance<= 0:
                break
            for i in range(width):
                for j in range(height):
                    if self.get_squaretype(i,j) != Wall:
                        if possiblemap[i][j] != True:
                            if j < height-1:
                                if possiblemap[i][j+1] == True:
                                    possiblemap[i][j] = "pending"

                            if j != 0:
                                if possiblemap[i][j-1] == True:
                                    possiblemap[i][j] = "pending"

                            if i < width-1:
                                if possiblemap[i+1][j] == True:
                                    possiblemap[i][j] = "pending"

                            if i != 0:
                                if possiblemap[i-1][j] == True:
                                    possiblemap[i][j] = "pending"

            for l in range(width):
                for m in range(height):
                    if possiblemap[l][m] == "pending":
                        possiblemap[l][m] = True
            distance -=1
        return possiblemap


    def get_can_see(self,x1,y1,x2,y2):
        x2 = int(x2)
        y2 = int(y2)
        xdistance = abs(x2-x1)
        ydistance = abs(y2-y1)
        cansee = True
        while True:
            if x1 == x2 and y1 == y2:
                break
            if self.get_squaretype(x1,y1) == Wall:
                cansee = False
                break
            if xdistance == 0:
                if y2 - y1 >= 0:
                    y1 += 1
                else:
                    y1 -= 1
            elif ydistance == 0:
                if x2-x1 >= 0:
                    x1 += 1
                else:
                    x1 -= 1
            if ydistance != 0:
                if xdistance != 0:
                    if (abs(x2-x1)/xdistance) < (abs(y2-y1)/ydistance):
                        if y2 - y1 >= 0:
                            y1 += 1
                        else:
                            y1 -= 1


                    if (abs(x2-x1)/xdistance) >= (abs(y2-y1)/ydistance):
                        if x2-x1 >= 0:
                            x1 += 1
                        else:
                            x1 -= 1




        return cansee

    def run_enemies(self):
        for enemy in self.enemies:
            for sound in self.sounds:
                if sound.can_hear(enemy):
                    self.enemystate = 1
                    for enemy2 in self.enemies:
                        enemy2.maketemproute()
        if self.enemystate == 0:
            for enemy in self.enemies:
                enemy.make_normal_move()
        elif self.enemystate == 1:
            for enemy in self.enemies:
                enemy.make_chase_move()
            lost = True
            for enemy in self.enemies:
                if not enemy.atbeginning:
                    lost = False
            if lost:
                self.enemystate = 0
        elif self.enemystate == 2:
            for enemy in self.enemies:
                enemy.shoot()
            if self.enemystate == 3:
                for enemy in self.enemies:
                    enemy.maketemproute()
        elif self.enemystate == 3:
            for enemy in self.enemies:
                enemy.make_chase_move()
            lost = True
            for enemy in self.enemies:
                if not enemy.atbeginning:
                    lost = False
            if lost:
                self.enemystate = 0


        self.GUI.create_sounds()
        self.sounds = []
        self.reset_state()

    def haswon(self):

        return self.player.get_square().get_type() == Winning_Square

    def open_box(self):
        if self.state != 3:
            self.reset_state()
            self.state = 3
            availmap = self.get_possible_squares(self.player.y, self.player.x, 1)
            for y in range(len(self.grid)):
                for x in range(len(self.grid[y])):
                    if availmap[x][y]:
                        self.grid[x][y].set_state(1)
        else:
            self.reset_state()

    def make_move(self):
        if self.state != 1:
            self.reset_state()
            self.state = 1
            availmap = self.get_possible_squares(self.player.y, self.player.x,self.player.walking_distance)
            for y in range(len(self.grid)):
                for x in range(len(self.grid[y])):
                    if availmap[x][y]:
                        self.grid[x][y].set_state(1)
        else:
            self.reset_state()

    def use_weapon(self):
        if self.state != 2:
            self.reset_state()
            self.state = 2
            availmap = self.get_possible_squares(self.player.y, self.player.x, Weapon.get_range(self.player.get_weapon()))
            for y in range(len(self.grid)):
                for x in range(len(self.grid[y])):
                    if availmap[x][y]:
                        if self.get_can_see(self.player.y, self.player.x, x, y):
                            self.grid[x][y].set_state(1)
        else:
            self.reset_state()


    def reset_state(self):
        self.set_visible_squares()
        self.set_visible_enemies()
        self.set_visible_boxes()
        self.state = 0

    def set_sounds(self,square,range,cause,issound):
        self.sounds.append(Sound(self,square,range,cause,issound))

    def set_visible_boxes(self):
        for box in self.boxes:
            box.targetgraphic.isvisible()



    def set_visible_enemies(self):
        for enemy in self.enemies:
            if self.grid[int(enemy.y)][int(enemy.x)].state == 0:
                enemy.turnvisible()
            elif self.grid[int(enemy.y)][int(enemy.x)].state == 1:
                enemy.turnvisible()
            else:
                enemy.turninvisible()
            enemy.graphicitem.update_location()


    def set_visible_squares(self):
        possiblemap = self.get_possible_squares(self.player.y, self.player.x, self.player.seeing_distance)
        for row in range(len(self.grid)):
            for square in self.grid[row]:
                if possiblemap[int(square.x)][int(square.y)]:
                    if self.get_can_see(self.player.y, self.player.x, int(square.x),int(square.y)):
                        square.set_state(0)


                    else:
                        square.set_state(2)
                else:
                    square.set_state(2)

    def do_level_action(self,x,y):

        actiondone = False
        if self.state == 1:
            actiondone = True
            self.player.move(x,y)
            self.reset_state()
        elif self.state == 2:
            for enemy in self.enemies:
                if self.player.energy >= Weapon.get_energy_cost(self.player.get_weapon()):
                    if enemy.x == y and enemy.y == x:
                        enemy.lose_hp(Weapon.get_damage(self.player.get_weapon()))
                        self.set_sounds(self.grid[self.player.x][self.player.y],Weapon.get_sound(self.player.get_weapon()),self.player,True)
                        self.player.energy -= Weapon.get_energy_cost(self.player.get_weapon())
                        self.reset_state()
                        actiondone = True

        elif self.state == 3:
            for box in self.boxes:
                if int(box.y) == int(x) and int(box.x) == int(y):
                    box.looted()
                    self.reset_state()
                    actiondone = True

        if self.haswon():
            self.GUI.win_popup()
        elif self.player.isdead():
            self.GUI.lose_popup()
        if actiondone:
            for enemy in self.enemies:
                if enemy.isdead():
                    enemy.graphicitem.deletegraphic()
                    self.enemies.remove(enemy)

            self.run_enemies()



    def game_over(self):
        pass

