Readme:
kaikki on yhdessä kansiossa, strategiapeli-y2-2021
toimiva ohjelma, jonka ajaa komentorivistä pelin kansiosta komennolla python main.py. Peli on demon kaltainen, voitto ja häviö lukitsevat pelaajan toiminnot ja pelaajan on pakko käynnistää peli uudelleen.
Täysin ajettavissa, sekä pelin kansiossa on testing.py, joka ajaa pari testiä, tarvitsee vain asentaa pyqt5. Koodi on täysin omaa, mutta pelaajahahmo ja vihollishahmo on kaverin luomaa taidetta omaksi ilokseni, älkää huomioiko arvostelussa niiden grafiikkaa.
peliä ohjataan valitsemalla toiminto ja sitten haluttu ruutu, tai vaihtoehto, ja sitä klikkaamalla, vaihtoehtoruudut on korostettu
pelissä ei ole muita kuin visuaalisia GUI- komentoja, ja erillinen testifile.

-Petteri Kippo