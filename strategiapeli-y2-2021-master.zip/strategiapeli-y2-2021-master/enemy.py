from facing import Facing

class Enemy():

    def __init__(self,x,y,facing,id):
        pass

    def addtargetgraphic(self,graphic):
        self.graphicitem = graphic


    def get_location(self):
        return (self.x, self.y)

    def get_graphics_location(self,squaresize):
        return (int(self.x)*squaresize, int(self.y)*squaresize)

    def get_enemytype(self):
        return self.enemytype

    def isvisible(self):
        return self.visible

    def turnvisible(self):
        if self.visible != True:
            self.visible = True

    def turninvisible(self):
        if self.visible != False:
            self.visible = False

    def get_facing_degree(self):
        return Facing.degrees(self.facing)

    def get_graphics(self):
        return self.graphics

    def get_id(self):
        return self.id

    def add_route(self,routedata):
        parts = routedata.split(",")
        routelist = []
        for part in parts:
            coordinates = part.split(":")
            if len(coordinates) == 2:
                routelist.append(coordinates)
        self.route = routelist

    def vision_cone_cansee(self,player):

        possiblemap = self.level.get_possible_squares(self.x, self.y,self.visionrange)
        insight = False
        xdiff = player.y - self.y
        ydiff = player.x - self.x
        if possiblemap[player.y][player.x]:
            if self.facing == Facing.DOWN:
                if xdiff > 0:
                    if abs(ydiff)/abs(xdiff) <= 0.5:
                        insight = True

            elif self.facing == Facing.UP:
                if xdiff < 0:
                    if abs(ydiff) / abs(xdiff) <= 0.5:
                        insight = True

            elif self.facing == Facing.RIGHT:
                if ydiff < 0:
                    if abs(xdiff) / abs(ydiff) <= 0.5:
                        insight = True
            # alas
            elif self.facing == Facing.LEFT:
                if ydiff > 0:
                    if  abs(xdiff)/ abs(ydiff) <= 0.5:
                        insight = True




        if insight:
            return self.level.get_can_see(self.x,self.y,player.y,player.x)
        else:
            return False


    def make_turn(self):
        pass

    def isdead(self):
        if self.hp <= 0:
            return True
        else:
            return False

    def lose_hp(self,loss):
        self.hp -= loss
        if not self.isdead():
            self.level.enemystate = 2
            self.level.lastseenpos = self.level.player.get_square()

    def get_route(self):
        return self.route