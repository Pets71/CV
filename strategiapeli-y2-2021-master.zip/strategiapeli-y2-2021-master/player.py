from graphics_item import Graphics_Item
from item import *
from facing import Facing


class Player:

    def __init__(self,x,y,facing,level):
        self.x = y
        self.y = x
        self.facing = facing
        self.level = level
        self.walking_distance = 3
        self.seeing_distance = 7
        self.inventory = [None] * 8
        self.energy = 20
        self.square = level.get_square(x,y)
        self.square.add_item(self)
        self.graphics = "the_main_char.png"
        self.graphicitem = None
        self.activeweapon = None
        self.hp = 20


    def move(self,x,y):
        self.x = y
        self.y = x
        self.square  = self.level.get_square(x,y)
        self.graphicitem.update_location()


    def add_to_inventory(self,item):
        for slot in range(len(self.inventory)):
            if self.inventory[slot] == None:
                self.inventory[slot] = item
                self.save_state()
                return True
        print("no room in inventory")
        return False

    def remove_item_from_inventory(self,target):
        for num in range(len(self.inventory)):
            if target == self.inventory[num]:
                self.inventory[num] = None
                return
        return

    def select_active_weapon(self,weapon):
        for item in self.inventory:
            if item == weapon:
                self.activeweapon = item

    def save_state(self):
        try:
            file = open("save.txt","w")
            for item in self.inventory:
                if item == None:
                    file.write("None")
                elif len(str(item)) == 1:
                    file.write(str(item))
                else:
                    for stat in item:
                        file.write(str(stat))
                file.write(":")
            file.close()
        except OSError:
            print("saving failed")

    def load_state(self):
        try:
            file = open("save.txt","r")
            line = file.readline()
            line = line.strip("\n")
            line = line.strip(":")
            new_inventory = []
            for items in line.split(":"):
                if items == "None":
                    new_inventory.append(None)
                elif len(str(items)) == 1:
                    new_inventory.append(tuple(items))
                else:
                    statlist = list(items)
                    for i in range(len(statlist)):
                        statlist[i] = int(statlist[i])
                    new_inventory.append(tuple(statlist))
            self.inventory = new_inventory
            file.close()
        except OSError:
            print("loading failed")



    def addtargetgraphic(self,graphic):
        self.graphicitem = graphic

    def turnvisible(self):
        pass

    def isvisible(self):
        return True

    def get_facing_degree(self):
        return Facing.degrees(self.facing)

    def get_location(self):
        return (self.x, self.y)

    def get_square(self):
        return self.square

    def get_graphics_location(self,squaresize):
        return (int(self.x)*squaresize, int(self.y)*squaresize)

    def get_graphics(self):
        return self.graphics

    def get_weapon(self):
        return self.activeweapon

    def lose_hp(self, loss):
        self.hp -= loss

    def isdead(self):
        return self.hp <= 0

